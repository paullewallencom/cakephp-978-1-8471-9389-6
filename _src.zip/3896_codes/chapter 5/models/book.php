<?php 
class Book extends AppModel
{
	var $name = 'Book';
}
?>