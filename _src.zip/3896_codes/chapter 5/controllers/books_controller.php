<?php
class BooksController extends AppController {
	var $name = 'Books';
	var $scaffold;
}
?>