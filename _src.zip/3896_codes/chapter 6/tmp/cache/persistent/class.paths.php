<?php
$config = array();
$config['Controllers']['BooksController'] = array('path' => 'C:\\wamp\\www\\old\\relationship\\app\\controllers\\books_controller.php', );
$config['Components']['Core']['SessionComponent'] = array('path' => 'C:\\wamp\\www\\old\\relationship\\cake\\libs\\controller\\components\\session.php', );
$config['Models']['Book'] = array('path' => 'C:\\wamp\\www\\old\\relationship\\app\\models\\book.php', );
$config['Models']['Author'] = array('path' => 'C:\\wamp\\www\\old\\relationship\\app\\models\\author.php', );
$config['Helpers']['Core']['HtmlHelper'] = array('path' => 'C:\\wamp\\www\\old\\relationship\\cake\\libs\\view\\helpers\\html.php', );
$config['Helpers']['Core']['SessionHelper'] = array('path' => 'C:\\wamp\\www\\old\\relationship\\cake\\libs\\view\\helpers\\session.php', );
