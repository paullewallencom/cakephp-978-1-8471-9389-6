<?php
class AppController extends Controller {

}
?>